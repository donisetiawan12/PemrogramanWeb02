<?php
require_once 'dbkoneksi.php';

$_kode = $_POST['kode'] ?? '';
$_nama = $_POST['nama'] ?? '';
$_tmp_lahir = $_POST['tmp_lahir'] ?? '';
$_tgl_lahir = $_POST['tgl_lahir'] ?? '';
$_gender = $_POST['gender'] ?? '';
$_email = $_POST['email'] ?? '';
$_alamat = $_POST['alamat'] ?? '';
$_kelurahan = $_POST['kelurahan'] ?? '';
$_proses = $_POST['proses'] ?? $_GET['proses'] ?? '';
$_idx = $_POST['idx'] ?? $_GET['id'] ?? '';

if ($_proses == "Simpan") {
    $sql = "INSERT INTO pasien (kode,nama,tmp_lahir,tgl_lahir,gender,email,alamat,kelurahan_id)
            VALUES ('$_kode','$_nama','$_tmp_lahir','$_tgl_lahir','$_gender','$_email','$_alamat','$_kelurahan')";
    mysqli_query($koneksi, $sql);
} else if ($_proses == "Ubah") {
    $sql = "UPDATE pasien SET kode='$_kode', nama='$_nama', tmp_lahir='$_tmp_lahir', tgl_lahir='$_tgl_lahir',
            gender='$_gender', email='$_email', alamat='$_alamat', kelurahan_id='$_kelurahan' WHERE id='$_idx'";
    mysqli_query($koneksi, $sql);
} else if ($_proses == "Hapus") {
    $sql = "DELETE FROM pasien WHERE id='$_idx'";
    mysqli_query($koneksi, $sql);
}
header("Location: data_pasien.php");
?>
