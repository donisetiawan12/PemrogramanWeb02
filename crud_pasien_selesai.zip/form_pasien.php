<?php
require_once 'dbkoneksi.php';

$idx = $_GET['id'] ?? '';
$tombol = 'Simpan';
$row = ['kode'=>'','nama'=>'','tmp_lahir'=>'','tgl_lahir'=>'','gender'=>'','email'=>'','alamat'=>'','kelurahan'=>''];

if ($idx != '') {
    $sql = "SELECT * FROM pasien WHERE id=?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("i", $idx);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $tombol = 'Ubah';
}
?>

<form method="POST" action="proses_pasien.php">
    <input type="text" name="kode" placeholder="Kode" value="<?= $row['kode'] ?>"><br>
    <input type="text" name="nama" placeholder="Nama" value="<?= $row['nama'] ?>"><br>
    <input type="text" name="tmp_lahir" placeholder="Tempat Lahir" value="<?= $row['tmp_lahir'] ?>"><br>
    <input type="date" name="tgl_lahir" value="<?= $row['tgl_lahir'] ?>"><br>
    <input type="radio" name="gender" value="L" <?= $row['gender']=='L'?'checked':'' ?>> Laki-laki
    <input type="radio" name="gender" value="P" <?= $row['gender']=='P'?'checked':'' ?>> Perempuan<br>
    <input type="email" name="email" placeholder="Email" value="<?= $row['email'] ?>"><br>
    <textarea name="alamat" placeholder="Alamat"><?= $row['alamat'] ?></textarea><br>
    <input type="text" name="kelurahan" placeholder="Kelurahan ID" value="<?= $row['kelurahan'] ?>"><br>
    <?php if ($idx): ?>
        <input type="hidden" name="idx" value="<?= $idx ?>">
    <?php endif; ?>
    <input type="submit" name="proses" value="<?= $tombol ?>">
</form>
<a href="data_pasien.php">Kembali</a>
