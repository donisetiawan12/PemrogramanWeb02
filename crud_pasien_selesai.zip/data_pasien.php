<?php
require_once 'dbkoneksi.php';
$sql = "SELECT * FROM pasien";
$rs = mysqli_query($koneksi, $sql);
?>
<h3>Data Pasien</h3>
<a href="form_pasien.php">Tambah Data</a>
<table border="1" cellpadding="5">
<tr><th>No</th><th>Kode</th><th>Nama</th><th>Email</th><th>Aksi</th></tr>
<?php $no=1; while($row = mysqli_fetch_assoc($rs)): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= $row['kode'] ?></td>
<td><?= $row['nama'] ?></td>
<td><?= $row['email'] ?></td>
<td>
    <a href="form_pasien.php?id=<?= $row['id'] ?>">Edit</a> |
    <a href="proses_pasien.php?id=<?= $row['id'] ?>&proses=Hapus" onclick="return confirm('Hapus data ini?')">Hapus</a>
</td>
</tr>
<?php endwhile; ?>
</table>
